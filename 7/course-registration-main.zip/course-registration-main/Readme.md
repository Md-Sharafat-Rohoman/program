# Course-Registration

## [ Private Repo Link](https://classroom.github.com/a/8TQS2mML)

Click here for the private repo: [https://classroom.github.com/a/8TQS2mML](https://classroom.github.com/a/8TQS2mML)



##  Questions

- Add at least 3 Project features 


- Discuss how you managed the state in your assignment project.